<nav>
    <ul>
        <li class="active"><a href="/bank_home"><i class="fa-solid fa-house"></i></a></li>
        <li class="desktop-only active"><a href="#" data-bs-toggle="modal" data-bs-target="#plusButtonModal"><i class="fa-solid fa-plus"></i></a></li>
        <li class="mobile-only"><a href="#"><i class="fa-solid fa-magnifying-glass"></i></a></li>
        <li class="mobile-only plus-button"><a href="#" data-bs-toggle="modal" data-bs-target="#plusButtonModal">
                <div class="plus-button">
                    <i class="fa-solid fa-plus"></i>
                </div>
            </a></li>
        <li><a href="#"><i class="material-icons">leaderboard</i></a></li>
        <li><a href="#"><i class="fa-regular fa-user"></i></a></li>
    </ul>
</nav>