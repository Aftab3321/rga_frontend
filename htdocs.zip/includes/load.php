<?php
define('ROOT_PATH', $_SERVER['DOCUMENT_ROOT']);
define('QUIZ_IMAGE_PATH', 'http://localhost:12345/');

require_once(ROOT_PATH.'/includes/config.php');
require_once(ROOT_PATH.'/includes/functions.php');
require_once(ROOT_PATH.'/includes/session.php');
require_once(ROOT_PATH.'/includes/upload.php');
require_once(ROOT_PATH.'/includes/database.php');
require_once(ROOT_PATH.'/includes/sql.php');

?>